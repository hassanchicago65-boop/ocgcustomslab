# OCG Marketplace for iPhone

Native SwiftUI app for iOS 17+. Bundle ID `com.ocgcustomslab.marketplace`, team `J4P53CTBDG`.

The iOS source in this folder is authoritative. The existing **OCG iOS Build** workflow copies it to the build directory; it no longer extracts the old source ZIP. Signing secrets and the upload checkbox are unchanged.

## Storefront

- OCG navy and gold storefront with a visible search field, category chips and price/name sorting.
- Consistent product cards, saved favorites, photo thumbnails and item links to the matching website listing.
- Local collection inventory with edit, delete and export, preserved across updates.
- Bundled, optimized product photos for immediate display even offline; bounded network requests, caching and a retry state for new images.
- Cached catalog fallback, with a compact notice if refresh fails.
- Checkout remains on the existing website. This change does not introduce accounts, in-app payment handling, a native cart or order tracking.

## Product updates

Edit `products.js`. Add an optimized copy of each new photo to `mobile-images/` and `ios/OCGMarketplace/Resources/ProductImages/`, retaining its original filename. Then run:

```
node scripts/export-ios-catalog.cjs
```

The marketplace includes Trading Cards, Coins, Clothing, Electronics, Stamps, Art & Paintings, Food & Beverages, Vintage & Collectibles, Home & Lifestyle, Ceramics & Pottery, and Other. Categories with no listings show a clear “coming soon” message until products are added.

Commit `catalog.json` and the matching bundled JSON file. GitHub Pages serves the root catalog and mobile images. The app can also display its bundled snapshot when offline. Listing prices and shipping are indicative; the merchant checkout confirms availability and the total.

## Testing and TestFlight

The **Check OCG storefront** workflow compiles and runs catalog and persistence tests on an iPhone simulator and saves a storefront screenshot. The **OCG iOS Build** workflow signs and uploads only when manually dispatched with `upload_to_testflight` enabled. Start a new run on the updated branch; rerunning an old run uses its original code.

The project includes all iPad orientations and declares that it uses only exempt encryption through Apple's operating system. Build versions expand from `CURRENT_PROJECT_VERSION`, so successive workflow runs produce distinct build numbers.
