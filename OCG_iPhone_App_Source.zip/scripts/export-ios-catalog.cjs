// Run after editing products.js, before publishing the website or an app build.
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const context = {window: {}};
vm.runInNewContext(fs.readFileSync(path.join(root, 'products.js'), 'utf8'), context, {timeout: 1000});
const products = context.window.OCG_PRODUCTS;
if (!Array.isArray(products) || !products.length) throw new Error('Catalog is empty');
const ids = new Set();
const catalog = products.map(p => {
  if (!p.id || ids.has(p.id) || !p.title || !Number.isFinite(p.price) || p.price < 0) throw new Error('Invalid product');
  ids.add(p.id);
  const images = [p.image, p.image2].filter(Boolean).map(image => {
    if (!fs.existsSync(path.join(root, image))) throw new Error(`Missing image: ${image}`);
    return new URL(image, 'https://ocgcustomslab.com/').href;
  });
  return {id: p.id, category: p.category, title: p.title, subtitle: p.subtitle || '', images,
    price: p.price, shipping: p.shipping || 0};
});
const output = JSON.stringify(catalog, null, 2) + '\n';
for (const file of ['catalog.json', 'ios/OCGMarketplace/Resources/catalog.json']) {
  fs.writeFileSync(path.join(root, file), output);
}
console.log(`Exported ${catalog.length} products. Prices are indicative; checkout verifies stock and totals.`);
