# OCG Marketplace for iPhone

Native SwiftUI first version, iOS 17+. Bundle ID `com.ocgcustomslab.marketplace`, team `J4P53CTBDG`.

## Included

- Searchable shop with category filters, item images and details.
- Favorites persisted locally.
- Personal collection inventory with add/edit/delete/search and text export.
- System share sheet, native navigation and accessibility labels.
- Existing website checkout opens in the system browser. The app never embeds PayPal code or accepts card details.
- No login, analytics SDK, advertising SDK, camera or location permission.
- Catalog refresh with saved/bundled fallback. Cached prices are labelled and checkout confirms actual inventory, shipping, tax and total.

## Catalog

Edit `products.js` as usual, then run `node scripts/export-ios-catalog.cjs` from the repository root. Commit both generated JSON files along with product changes. The app reads `https://ocgcustomslab.com/catalog.json`; this URL exists only after the branch is merged and the website is deployed. Product status is not presented as live inventory: the PayPal stock system is the final authority. The sold Austria coin still exists in the website catalog, so it is not labelled available by the app.

## Build on a cloud Mac from Windows

The draft PR runs `.github/workflows/ios-build.yml` on GitHub's macOS runner. It generates an Xcode project with XcodeGen, compiles the simulator app, and runs persistence/catalog tests. The simulator artifact cannot be installed on an iPhone.

To work on a Mac: `brew install xcodegen`, `cd ios`, `xcodegen generate`, then open `OCGMarketplace.xcodeproj`.

## Remaining before TestFlight / App Review

1. Run the cloud build and resolve any compiler/test failures. Run on a physical iPhone, including offline, Dynamic Type, deletion/export, refresh and browser checkout return behavior.
2. Supply the approved 1024×1024 app icon, create an AppIcon asset catalog and set `ASSETCATALOG_COMPILER_APPICON_NAME`. Existing website logo is 221×253 and is not an App Store icon.
3. Configure a signed cloud archive with an Apple Distribution certificate and App Store provisioning profile (or managed signing). Keep signing keys and App Store Connect API key in encrypted CI secrets, never repository files or chat. Only then can a signed IPA be uploaded to TestFlight. The current CI does not sign or upload.
4. Confirm current shipping rates and tax treatment on the website; this app does not change or certify them.
5. Publish a dedicated app privacy policy at a stable URL covering local collection/favorites, catalog/image hosting requests, browser checkout and support. The existing link points to the website privacy section and must be reviewed for app scope.
6. Audit host logs, checkout and support practices before answering App Privacy. An empty collected-data array in the manifest is not proof that App Store Connect should say 'No data collected'. UserDefaults reason CA92.1 covers app-only preferences and collection storage.
7. App Review sign-in required should be unchecked for this version; there is no app account. Complete screenshots, app privacy, content rights and review metadata. Approval is determined by Apple, and is not guaranteed.

## CI costs

GitHub Actions macOS minutes may be charged according to the repository/account plan. This workflow is manually or PR triggered, capped at 25 minutes, and does not deploy the website or publish an app.
