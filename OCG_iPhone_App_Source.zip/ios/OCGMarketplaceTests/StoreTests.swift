import XCTest
@testable import OCGMarketplace

final class StoreTests: XCTestCase {
    private func catalog(_ ids: [String]) -> Data {
        let items = ids.map { ["id": $0, "category": "Coins", "title": "Coin", "subtitle": "", "images": ["https://ocgcustomslab.com/coin.jpg"], "price": 3.5, "shipping": 1.36] as [String: Any] }
        return try! JSONSerialization.data(withJSONObject: items)
    }
    func testRejectsDuplicateProductIDsAndEmptyCatalog() {
        XCTAssertThrowsError(try Catalog.decode(catalog(["one", "one"])))
        XCTAssertThrowsError(try Catalog.decode(catalog([])))
        XCTAssertEqual(try Catalog.decode(catalog(["one"])).first?.price, 3.5)
    }
    func testRejectsUntrustedImages() {
        let invalid = String(data: catalog(["one"]), encoding: .utf8)!.replacingOccurrences(of: "ocgcustomslab.com", with: "example.com")
        XCTAssertThrowsError(try Catalog.decode(Data(invalid.utf8)))
    }
    func testBundledCatalogIncludesDecodableOfflinePhotos() throws {
        let url = try XCTUnwrap(Bundle.main.url(forResource: "catalog", withExtension: "json"))
        let products = try Catalog.decode(Data(contentsOf: url))
        for product in products {
            for image in product.images {
                let local = Bundle.main.url(forResource: image.lastPathComponent, withExtension: nil)
                    ?? Bundle.main.url(forResource: image.lastPathComponent, withExtension: nil, subdirectory: "ProductImages")
                let photo = try XCTUnwrap(local, "Missing offline photo for \(product.title)")
                XCTAssertGreaterThan(try Data(contentsOf: photo).count, 0)
            }
        }
    }
    @MainActor
    func testFavoritesAndCollectionSurviveReload() {
        let suite = "tests-\(UUID())"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = Store(defaults: defaults)
        store.toggleFavorite("coin")
        var item = CollectionItem(title: "My coin", category: "Coins", notes: "Fine")
        store.save(item)
        item.notes = "Very fine"
        store.save(item)
        let reloaded = Store(defaults: defaults)
        XCTAssertTrue(reloaded.favorites.contains("coin"))
        XCTAssertEqual(reloaded.collection.count, 1)
        XCTAssertEqual(reloaded.collection.first?.notes, "Very fine")
        reloaded.remove([item.id])
        XCTAssertTrue(Store(defaults: defaults).collection.isEmpty)
    }
    @MainActor
    func testCartQuantityAndContentsSurviveReload() throws {
        let suite = "tests-\(UUID())"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = Store(defaults: defaults)
        let product = try XCTUnwrap(store.products.first)
        store.addToCart(product.id)
        store.addToCart(product.id)
        store.setCartQuantity(3, for: product.id)

        let reloaded = Store(defaults: defaults)
        XCTAssertEqual(reloaded.cart[product.id], 3)
        XCTAssertEqual(reloaded.cartCount, 3)
        XCTAssertEqual(reloaded.cartSubtotal, product.price * 3)
        reloaded.removeFromCart(product.id)
        XCTAssertEqual(Store(defaults: defaults).cartCount, 0)
    }
    @MainActor
    func testCorruptCollectionIsNotOverwritten() {
        let suite = "tests-\(UUID())"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let corrupt = Data("broken".utf8)
        defaults.set(corrupt, forKey: "collection")
        let store = Store(defaults: defaults)
        XCTAssertNotNil(store.storageError)
        store.save(CollectionItem(title: "New item", category: "Coins", notes: ""))
        XCTAssertEqual(defaults.data(forKey: "collection"), corrupt)
    }
}
