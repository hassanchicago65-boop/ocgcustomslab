import XCTest
@testable import OCGMarketplace

final class StoreTests: XCTestCase {
    private func catalog(_ ids: [String]) -> Data {
        let items = ids.map { ["id": $0, "category": "Coins", "title": "Coin", "subtitle": "", "images": ["https://ocgcustomslab.com/coin.jpg"], "price": 3.5, "shipping": 1.36] as [String: Any] }
        return try! JSONSerialization.data(withJSONObject: items)
    }
    func testRejectsDuplicateProductIDsAndEmptyCatalog() {
        XCTAssertThrowsError(try Catalog.decode(catalog(["one", "one"])))
        XCTAssertThrowsError(try Catalog.decode(catalog([])))
        XCTAssertEqual(try Catalog.decode(catalog(["one"])).first?.price, 3.5)
    }
    func testRejectsUntrustedImages() {
        let invalid = String(data: catalog(["one"]), encoding: .utf8)!.replacingOccurrences(of: "ocgcustomslab.com", with: "example.com")
        XCTAssertThrowsError(try Catalog.decode(Data(invalid.utf8)))
    }
    @MainActor
    func testFavoritesAndCollectionSurviveReload() {
        let suite = "tests-\(UUID())"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = Store(defaults: defaults)
        store.toggleFavorite("coin")
        var item = CollectionItem(title: "My coin", category: "Coins", notes: "Fine")
        store.save(item)
        item.notes = "Very fine"
        store.save(item)
        let reloaded = Store(defaults: defaults)
        XCTAssertTrue(reloaded.favorites.contains("coin"))
        XCTAssertEqual(reloaded.collection.count, 1)
        XCTAssertEqual(reloaded.collection.first?.notes, "Very fine")
        reloaded.remove([item.id])
        XCTAssertTrue(Store(defaults: defaults).collection.isEmpty)
    }
    @MainActor
    func testCorruptCollectionIsNotOverwritten() {
        let suite = "tests-\(UUID())"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let corrupt = Data("broken".utf8)
        defaults.set(corrupt, forKey: "collection")
        let store = Store(defaults: defaults)
        XCTAssertNotNil(store.storageError)
        store.save(CollectionItem(title: "New item", category: "Coins", notes: ""))
        XCTAssertEqual(defaults.data(forKey: "collection"), corrupt)
    }
}
