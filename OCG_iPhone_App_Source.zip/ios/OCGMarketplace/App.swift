import SwiftUI
import UIKit

private enum OCGStyle {
    static let navy = Color(red: 0.10, green: 0.16, blue: 0.29)
    static let gold = Color(red: 0.77, green: 0.57, blue: 0.25)
    static let canvas = Color(.systemGroupedBackground)
    static let marketplaceCategories = [
        "Trading Cards", "Coins", "Clothing", "Electronics", "Stamps",
        "Art & Paintings", "Food & Beverages", "Vintage & Collectibles",
        "Home & Lifestyle", "Ceramics & Pottery", "Other"
    ]
    static func categoryName(_ name: String) -> String {
        switch name {
        case "Trading Cards": return "Cards"
        case "Art & Paintings": return "Art"
        case "Food & Beverages": return "Food & drinks"
        case "Vintage & Collectibles": return "Collectibles"
        case "Ceramics & Pottery": return "Pottery"
        case "Home & Lifestyle": return "Home"
        default: return name
        }
    }
    static func symbol(_ name: String) -> String {
        switch name {
        case "Trading Cards": return "rectangle.portrait.on.rectangle.portrait"
        case "Coins": return "circle.circle"
        case "Clothing": return "tshirt"
        case "Electronics": return "bolt.horizontal.circle"
        case "Stamps": return "seal"
        case "Art & Paintings": return "paintpalette"
        case "Food & Beverages": return "cup.and.saucer"
        case "Ceramics & Pottery": return "carrot"
        case "Home & Lifestyle": return "house"
        case "Vintage & Collectibles": return "clock.arrow.circlepath"
        default: return "square.grid.2x2"
        }
    }
}

@main
struct OCGMarketplaceApp: App {
    @StateObject private var store = Store()
    var body: some Scene {
        WindowGroup {
            TabView {
                ShopView().tabItem { Label("Shop", systemImage: "bag") }
                CartView().tabItem { Label("Cart", systemImage: "cart") }.badge(store.cartCount)
                ShopView(favoritesOnly: true).tabItem { Label("Saved", systemImage: "heart") }
                CollectionView().tabItem { Label("Collection", systemImage: "square.stack.3d.up") }
                AboutView().tabItem { Label("Help", systemImage: "questionmark.circle") }
            }
            .tint(OCGStyle.navy)
            .environmentObject(store)
            .task { await store.refresh() }
        }
    }
}

struct ProductImage: View {
    let url: URL?
    @StateObject private var loader = ProductImageLoader()
    @State private var retry = 0
    var body: some View {
        Group {
            if let image = loader.image {
                Image(uiImage: image).resizable().scaledToFit()
            } else if loader.failed {
                VStack(spacing: 8) {
                    Image(systemName: "photo").font(.title2)
                    Button("Retry image") { retry += 1 }.font(.caption)
                }.foregroundStyle(.secondary)
            } else {
                ProgressView().accessibilityLabel("Loading product image")
            }
        }
        .task(id: "\(url?.absoluteString ?? "")-\(retry)") { await loader.load(url) }
    }
}

private enum ProductSort: String, CaseIterable {
    case featured = "Featured"
    case lowPrice = "Price: low to high"
    case highPrice = "Price: high to low"
    case title = "Name: A to Z"
}

struct ShopView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.dynamicTypeSize) private var textSize
    var favoritesOnly = false
    @State private var search = ""
    @State private var category = "All"
    @State private var sort = ProductSort.featured
    private var categories: [String] {
        let catalogCategories = Set(store.products.map(\.category))
        let standard = OCGStyle.marketplaceCategories
        let additional = catalogCategories.subtracting(standard).sorted()
        return ["All"] + standard + additional
    }
    private var filtered: [Product] {
        let products = store.products.filter {
            (!favoritesOnly || store.favorites.contains($0.id)) &&
            (category == "All" || $0.category == category) &&
            (search.isEmpty || ($0.title + " " + $0.subtitle + " " + $0.category).localizedCaseInsensitiveContains(search))
        }
        switch sort {
        case .featured: return products
        case .lowPrice: return products.sorted { $0.price < $1.price }
        case .highPrice: return products.sorted { $0.price > $1.price }
        case .title: return products.sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
        }
    }
    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 12), count: textSize.isAccessibilitySize ? 1 : 2)
    }
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                searchField.padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 12)
                    .background(Color(.systemBackground))
                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 22) {
                            if !favoritesOnly && search.isEmpty && category == "All" {
                                hero {
                                    withAnimation { proxy.scrollTo("products", anchor: .top) }
                                }
                            }
                            categoryFilters
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(favoritesOnly ? "Your favorites" : category == "All" ? "Explore the shop" : category)
                                            .font(.title3.bold())
                                        Text("\(filtered.count) \(filtered.count == 1 ? "item" : "items")")
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Menu {
                                        Picker("Sort products", selection: $sort) {
                                            ForEach(ProductSort.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                                        }
                                    } label: {
                                        Label("Sort", systemImage: "arrow.up.arrow.down").font(.subheadline.weight(.medium))
                                    }.accessibilityLabel("Sort products, \(sort.rawValue)")
                                }.id("products")
                                if store.catalogOffline {
                                    HStack(spacing: 6) {
                                        Image(systemName: "wifi.slash")
                                        Text("Saved catalog · Pull down to refresh")
                                    }.font(.caption).foregroundStyle(.secondary)
                                }
                                if filtered.isEmpty {
                                    let categoryComingSoon = !favoritesOnly && category != "All" &&
                                        !store.products.contains(where: { $0.category == category })
                                    ContentUnavailableView(
                                        favoritesOnly ? "No saved items" : categoryComingSoon ? OCGStyle.categoryName(category) + " coming soon" : "No matching items",
                                        systemImage: favoritesOnly ? "heart" : categoryComingSoon ? OCGStyle.symbol(category) : "magnifyingglass",
                                        description: Text(favoritesOnly ? "Tap a heart on any item to keep it here." : categoryComingSoon ? "New OCG listings will appear in this category." : "Try a different search or category."))
                                } else {
                                    LazyVGrid(columns: columns, alignment: .leading, spacing: 16) {
                                        ForEach(filtered) { product in ProductCard(product: product) }
                                    }
                                }
                            }
                            if !filtered.isEmpty {
                                HStack(alignment: .top, spacing: 9) {
                                    Image(systemName: "shippingbox").foregroundStyle(OCGStyle.gold)
                                    Text("Stock, shipping and tax are confirmed at checkout on our website.")
                                        .font(.caption).foregroundStyle(.secondary)
                                }.padding(.vertical, 6)
                            }
                        }.padding(16).padding(.bottom, 16)
                    }
                    .scrollDismissesKeyboard(.interactively)
                    .refreshable { await store.refresh() }
                }
            }
            .background(OCGStyle.canvas)
            .navigationTitle(favoritesOnly ? "Saved items" : "OCG Marketplace")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    if favoritesOnly { Text("Saved items").font(.headline) }
                    else {
                        HStack(spacing: 8) {
                            Image("ocg-brand", bundle: .main).resizable().scaledToFit().frame(width: 29, height: 32)
                            VStack(alignment: .leading, spacing: 0) {
                                Text("OCG").font(.headline.weight(.heavy))
                                Text("MARKETPLACE").font(.system(size: 8, weight: .semibold)).tracking(1.6)
                            }.foregroundStyle(OCGStyle.navy)
                        }.accessibilityElement(children: .ignore).accessibilityLabel("OCG Marketplace")
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { Task { await store.refresh() } } label: {
                        if store.loading { ProgressView() }
                        else { Image(systemName: "arrow.clockwise").font(.subheadline.weight(.semibold)) }
                    }.disabled(store.loading).accessibilityLabel("Refresh catalog")
                }
            }
        }
    }
    private var searchField: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField(favoritesOnly ? "Search saved items" : "Search cards, coins, art & more", text: $search)
                .font(.subheadline).submitLabel(.search).autocorrectionDisabled()
                .accessibilityIdentifier("product-search")
            if !search.isEmpty {
                Button { search = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                    .accessibilityLabel("Clear search")
            }
        }.padding(12).background(OCGStyle.canvas, in: RoundedRectangle(cornerRadius: 10))
    }
    private var categoryFilters: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(categories, id: \.self) { value in
                    Button { category = value } label: {
                        Label(OCGStyle.categoryName(value), systemImage: OCGStyle.symbol(value))
                            .font(.caption.weight(.semibold)).padding(.horizontal, 13).padding(.vertical, 11)
                            .foregroundStyle(category == value ? Color.white : OCGStyle.navy)
                            .background(category == value ? OCGStyle.navy : Color(.systemBackground), in: Capsule())
                    }.buttonStyle(.plain).accessibilityAddTraits(category == value ? .isSelected : [])
                }
            }
        }.contentMargins(.trailing, 1)
    }
    private func hero(shop: @escaping () -> Void) -> some View {
        HStack(alignment: .center, spacing: 10) {
            VStack(alignment: .leading, spacing: 10) {
                Text("THE OCG EDIT").font(.system(size: 9, weight: .bold)).tracking(2).foregroundStyle(Color(red: 0.94, green: 0.79, blue: 0.52))
                Text("Find something\nworth keeping.").font(.system(.title2, design: .serif, weight: .semibold)).foregroundStyle(.white)
                    .fixedSize(horizontal: false, vertical: true)
                Text("Cards. Coins. One-of-a-kind finds.").font(.caption).foregroundStyle(.white.opacity(0.72))
                    .fixedSize(horizontal: false, vertical: true)
                Button(action: shop) {
                    HStack(spacing: 8) { Text("Explore collection"); Image(systemName: "arrow.right") }
                        .font(.caption.weight(.bold)).foregroundStyle(OCGStyle.navy)
                        .padding(.horizontal, 12).padding(.vertical, 10)
                        .background(Color(red: 0.94, green: 0.79, blue: 0.52), in: Capsule())
                }.padding(.top, 3)
            }.frame(maxWidth: .infinity, alignment: .leading)
            if !textSize.isAccessibilitySize, let product = store.products.first(where: { $0.category == "Trading Cards" }) {
                NavigationLink { ProductDetail(product: product) } label: {
                    ProductImage(url: product.images.first).padding(6).frame(width: 100, height: 142)
                        .background(.white, in: RoundedRectangle(cornerRadius: 8))
                        .rotationEffect(.degrees(7)).shadow(color: .black.opacity(0.25), radius: 10, y: 6)
                }.buttonStyle(.plain).accessibilityLabel(product.title)
            }
        }.padding(20).background(OCGStyle.navy, in: RoundedRectangle(cornerRadius: 16))
    }
}

private struct ProductCard: View {
    @EnvironmentObject private var store: Store
    let product: Product
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ZStack(alignment: .topTrailing) {
                NavigationLink { ProductDetail(product: product) } label: {
                    ProductImage(url: product.images.first).padding(10)
                        .frame(maxWidth: .infinity).frame(height: 172)
                        .background(Color(.systemBackground))
                }.buttonStyle(.plain).accessibilityLabel("View \(product.title)")
                Button { store.toggleFavorite(product.id) } label: {
                    Image(systemName: store.favorites.contains(product.id) ? "heart.fill" : "heart")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(store.favorites.contains(product.id) ? .red : OCGStyle.navy)
                        .frame(width: 36, height: 36).background(.regularMaterial, in: Circle())
                }.padding(8).accessibilityLabel("\(store.favorites.contains(product.id) ? "Unsave" : "Save") \(product.title)")
            }
            NavigationLink { ProductDetail(product: product) } label: {
                VStack(alignment: .leading, spacing: 6) {
                    Text(OCGStyle.categoryName(product.category).uppercased())
                        .font(.system(size: 9, weight: .semibold)).tracking(0.8).foregroundStyle(.secondary)
                    Text(product.title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                        .lineLimit(2, reservesSpace: true).multilineTextAlignment(.leading)
                    Text(product.price, format: .currency(code: "USD"))
                        .font(.headline.weight(.bold)).foregroundStyle(OCGStyle.navy).padding(.top, 2)
                }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
            }.buttonStyle(.plain)
        }
        .background(Color(.systemBackground), in: RoundedRectangle(cornerRadius: 12))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.primary.opacity(0.06), lineWidth: 1))
    }
}

struct ProductDetail: View {
    @EnvironmentObject private var store: Store
    let product: Product
    @State private var addToCollection = false
    @State private var selectedImage = 0
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                VStack(spacing: 10) {
                    TabView(selection: $selectedImage) {
                        ForEach(Array(product.images.enumerated()), id: \.offset) { index, url in
                            ProductImage(url: url).padding(20).tag(index)
                        }
                    }.tabViewStyle(.page(indexDisplayMode: .never)).frame(height: 290)
                    if product.images.count > 1 {
                        HStack(spacing: 10) {
                            ForEach(Array(product.images.enumerated()), id: \.offset) { index, url in
                                Button { selectedImage = index } label: {
                                    ProductImage(url: url).padding(5).frame(width: 48, height: 54)
                                        .background(Color(.systemBackground), in: RoundedRectangle(cornerRadius: 6))
                                        .overlay(RoundedRectangle(cornerRadius: 6).stroke(selectedImage == index ? OCGStyle.gold : Color.primary.opacity(0.1), lineWidth: selectedImage == index ? 2 : 1))
                                }.accessibilityLabel("Product photo \(index + 1)")
                            }
                        }.padding(.bottom, 14)
                    }
                }.frame(maxWidth: .infinity).background(Color(.systemBackground), in: RoundedRectangle(cornerRadius: 14))
                VStack(alignment: .leading, spacing: 10) {
                    Text(product.category.uppercased()).font(.caption2.weight(.semibold)).tracking(1).foregroundStyle(OCGStyle.gold)
                    Text(product.title).font(.title2.bold()).fixedSize(horizontal: false, vertical: true)
                    Text(product.subtitle).font(.subheadline).foregroundStyle(.secondary)
                    Text(product.price, format: .currency(code: "USD")).font(.title.bold()).foregroundStyle(OCGStyle.navy)
                }
                VStack(alignment: .leading, spacing: 12) {
                    Label(product.shipping == 0 ? "Listed U.S. shipping: Free" : "Listed U.S. shipping: \(product.shipping.formatted(.currency(code: "USD")))", systemImage: "shippingbox")
                    Label("Final stock and total confirmed at checkout", systemImage: "checkmark.shield")
                }.font(.caption).foregroundStyle(.secondary)
                Button { store.addToCart(product.id) } label: {
                    Label("Add to cart", systemImage: "cart.badge.plus")
                        .font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity).padding(16)
                        .foregroundStyle(.white).background(OCGStyle.navy, in: RoundedRectangle(cornerRadius: 12))
                }.accessibilityIdentifier("add-to-cart")
                Link(destination: product.websiteURL) {
                    HStack { Text("Shop this item on OCG"); Spacer(); Image(systemName: "arrow.up.right") }
                        .font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity).padding(16)
                        .foregroundStyle(.white).background(OCGStyle.navy, in: RoundedRectangle(cornerRadius: 12))
                }
                HStack(spacing: 12) {
                    Button { store.toggleFavorite(product.id) } label: {
                        Label(store.favorites.contains(product.id) ? "Saved" : "Save item", systemImage: store.favorites.contains(product.id) ? "heart.fill" : "heart")
                            .frame(maxWidth: .infinity)
                    }
                    Button { addToCollection = true } label: {
                        Label("Collection", systemImage: "plus").frame(maxWidth: .infinity)
                    }.disabled(store.storageError != nil)
                }.font(.subheadline).buttonStyle(.bordered)
                Text("About this item").font(.headline)
                Text(product.subtitle.isEmpty ? product.title : product.subtitle).font(.subheadline).foregroundStyle(.secondary)
                Text("Complete your purchase on our website. Availability, delivery options, tax and the final total are shown there.")
                    .font(.caption).foregroundStyle(.secondary)
            }.padding(16).padding(.bottom, 20)
        }
        .background(OCGStyle.canvas)
        .navigationTitle("Item details").navigationBarTitleDisplayMode(.inline)
        .toolbar { ShareLink(item: product.websiteURL) { Image(systemName: "square.and.arrow.up") }.accessibilityLabel("Share \(product.title)") }
        .sheet(isPresented: $addToCollection) { CollectionEditor(item: CollectionItem(title: product.title, category: product.category, notes: "")) }
    }
}

struct CartView: View {
    @EnvironmentObject private var store: Store

    var body: some View {
        NavigationStack {
            Group {
                if store.cartLines.isEmpty {
                    ContentUnavailableView("Your cart is empty", systemImage: "cart", description: Text("Add an item from the shop to start your order."))
                } else {
                    List {
                        Section("Items") {
                            ForEach(store.cartLines) { line in
                                VStack(alignment: .leading, spacing: 8) {
                                    HStack(alignment: .top) {
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(line.product.title).font(.headline)
                                            Text(line.product.category).font(.caption).foregroundStyle(.secondary)
                                            Text(line.product.price, format: .currency(code: "USD"))
                                                .font(.subheadline.weight(.semibold))
                                        }
                                        Spacer()
                                        Button(role: .destructive) { store.removeFromCart(line.product.id) } label: {
                                            Image(systemName: "trash")
                                        }.accessibilityLabel("Remove \(line.product.title) from cart")
                                    }
                                    Stepper("Quantity: \(line.quantity)", value: Binding(
                                        get: { store.cart[line.product.id] ?? line.quantity },
                                        set: { store.setCartQuantity($0, for: line.product.id) }
                                    ), in: 1...99)
                                    Text("Listed shipping: \((line.product.shipping * Double(line.quantity)).formatted(.currency(code: "USD")))")
                                        .font(.caption).foregroundStyle(.secondary)
                                }.padding(.vertical, 4)
                            }
                        }
                        Section("Estimated total") {
                            LabeledContent("Items", value: store.cartSubtotal.formatted(.currency(code: "USD")))
                            LabeledContent("Listed shipping", value: store.cartShippingEstimate.formatted(.currency(code: "USD")))
                            LabeledContent("Before tax", value: (store.cartSubtotal + store.cartShippingEstimate).formatted(.currency(code: "USD")))
                            Text("Tax and final shipping are confirmed at checkout. Checkout connection is the next setup step.")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("Cart").navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct CollectionView: View {
    @EnvironmentObject private var store: Store
    @State private var editing: CollectionItem?
    @State private var search = ""
    private var items: [CollectionItem] {
        store.collection.filter { search.isEmpty || ($0.title + " " + $0.category + " " + $0.notes).localizedCaseInsensitiveContains(search) }
    }
    var body: some View {
        NavigationStack {
            List {
                Section { Text("Keep track of the pieces you own. Your personal inventory is saved on this device.").font(.subheadline).foregroundStyle(.secondary) }
                if let error = store.storageError { Text(error).foregroundStyle(.red) }
                if items.isEmpty {
                    ContentUnavailableView("Your collection starts here", systemImage: "square.stack.3d.up", description: Text("Add cards, coins and other pieces with the + button."))
                }
                ForEach(items) { item in
                    Button { editing = item } label: {
                        HStack(spacing: 12) {
                            Image(systemName: OCGStyle.symbol(item.category)).frame(width: 36, height: 40).foregroundStyle(OCGStyle.gold)
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.title).font(.headline).foregroundStyle(.primary)
                                Text(item.category).font(.caption).foregroundStyle(.secondary)
                                if !item.notes.isEmpty { Text(item.notes).font(.subheadline).foregroundStyle(.secondary).lineLimit(2) }
                            }
                        }
                    }.disabled(store.storageError != nil)
                }.onDelete { offsets in store.remove(Set(offsets.map { items[$0].id })) }
            }
            .navigationTitle("My collection").navigationBarTitleDisplayMode(.inline)
            .searchable(text: $search, prompt: "Search your collection")
            .toolbar {
                Button { editing = CollectionItem(title: "", category: "Trading Cards", notes: "") } label: { Image(systemName: "plus") }
                    .disabled(store.storageError != nil).accessibilityLabel("Add collection item")
                if !store.collection.isEmpty {
                    ShareLink(item: store.collection.map { "\($0.title) | \($0.category)\n\($0.notes)" }.joined(separator: "\n\n")) {
                        Image(systemName: "square.and.arrow.up")
                    }.accessibilityLabel("Export collection")
                }
            }
            .sheet(item: $editing) { CollectionEditor(item: $0) }
        }
    }
}

struct CollectionEditor: View {
    @EnvironmentObject private var store: Store
    @Environment(\.dismiss) private var dismiss
    @State var item: CollectionItem
    var body: some View {
        NavigationStack {
            Form {
                TextField("Item name", text: $item.title)
                TextField("Category", text: $item.category)
                Section("Notes, condition or certificate number") { TextEditor(text: $item.notes).frame(minHeight: 140) }
                Text("Stored on this device. Export before deleting the app. Adding an item does not purchase it.").font(.footnote)
            }
            .navigationTitle("Collection item").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        item.title = item.title.trimmingCharacters(in: .whitespacesAndNewlines)
                        store.save(item); dismiss()
                    }.disabled(item.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || store.storageError != nil)
                }
            }
        }
    }
}

struct AboutView: View {
    var body: some View {
        NavigationStack {
            List {
                Section("OCG Marketplace") {
                    Text("Cards, coins, original art and everyday discoveries. Save your favorites and keep track of your collection.")
                    Link("Visit OCG website", destination: URL(string: "https://ocgcustomslab.com/")!)
                }
                Section("Orders and support") {
                    Text("Complete purchases on the OCG website. For questions about an order, contact us below.")
                    Link(destination: URL(string: "mailto:hassanchicago65@gmail.com")!) { Label("Email OCG", systemImage: "envelope") }
                    Link("Shipping and returns", destination: URL(string: "https://ocgcustomslab.com/#returns")!)
                }
                Section("Privacy") {
                    Text("Favorites and collection notes stay on this device. No account is required. The app downloads product information and images from OCG. Purchases are handled by your browser and the website checkout providers.")
                    Link("Privacy policy", destination: URL(string: "https://ocgcustomslab.com/#privacy")!)
                }
                Section { Text("Version \(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0")").foregroundStyle(.secondary) }
            }.navigationTitle("Help & support").navigationBarTitleDisplayMode(.inline)
        }
    }
}
