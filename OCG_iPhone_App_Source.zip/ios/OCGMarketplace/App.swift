import SwiftUI

@main
struct OCGMarketplaceApp: App {
    @StateObject private var store = Store()
    var body: some Scene {
        WindowGroup {
            TabView {
                ShopView().tabItem { Label("Shop", systemImage: "bag") }
                ShopView(favoritesOnly: true).tabItem { Label("Saved", systemImage: "heart") }
                CollectionView().tabItem { Label("Collection", systemImage: "square.stack.3d.up") }
                AboutView().tabItem { Label("Help", systemImage: "questionmark.circle") }
            }
            .tint(Color(red: 0.12, green: 0.20, blue: 0.37))
            .environmentObject(store)
            .task { await store.refresh() }
        }
    }
}

struct ProductImage: View {
    let url: URL?
    var body: some View {
        AsyncImage(url: url) { phase in
            if let image = phase.image { image.resizable().scaledToFit() }
            else if phase.error != nil { Image(systemName: "photo").font(.largeTitle).foregroundStyle(.secondary).accessibilityLabel("Image unavailable") }
            else { ProgressView() }
        }
    }
}

struct ShopView: View {
    @EnvironmentObject private var store: Store
    var favoritesOnly = false
    @State private var search = ""
    @State private var category = "All"
    private var categories: [String] { ["All"] + Set(store.products.map(\.category)).sorted() }
    private var filtered: [Product] {
        store.products.filter {
            (!favoritesOnly || store.favorites.contains($0.id)) && (category == "All" || $0.category == category) &&
            (search.isEmpty || ($0.title + " " + $0.subtitle + " " + $0.category).localizedCaseInsensitiveContains(search))
        }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if !favoritesOnly {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Discover your next treasure").font(.largeTitle.bold())
                            Text("Cards, coins, art and more from OCG.").foregroundStyle(.secondary)
                        }.padding(.top)
                    }
                    Picker("Category", selection: $category) {
                        ForEach(categories, id: \.self) { Text($0).tag($0) }
                    }.pickerStyle(.menu)
                    Text(store.catalogMessage).font(.caption).foregroundStyle(.secondary)
                    if filtered.isEmpty {
                        ContentUnavailableView(favoritesOnly ? "No saved items" : "No matching items",
                            systemImage: favoritesOnly ? "heart" : "magnifyingglass",
                            description: Text(favoritesOnly ? "Save products with the heart button to find them here." : "Try another search or category."))
                    }
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 16)], spacing: 24) {
                        ForEach(filtered) { product in
                            VStack(alignment: .leading, spacing: 8) {
                                NavigationLink {
                                    ProductDetail(product: product)
                                } label: {
                                    VStack(alignment: .leading, spacing: 8) {
                                        ProductImage(url: product.images.first)
                                            .frame(height: 170).frame(maxWidth: .infinity)
                                            .background(Color(.secondarySystemBackground)).clipShape(RoundedRectangle(cornerRadius: 16))
                                        Text(product.category.uppercased()).font(.caption2).foregroundStyle(.secondary)
                                        Text(product.title).font(.headline).foregroundStyle(.primary).lineLimit(3)
                                        Text(product.price, format: .currency(code: "USD")).font(.subheadline.bold()).foregroundStyle(.primary)
                                    }
                                }.buttonStyle(.plain)
                                Button { store.toggleFavorite(product.id) } label: {
                                    Label(store.favorites.contains(product.id) ? "Saved" : "Save",
                                        systemImage: store.favorites.contains(product.id) ? "heart.fill" : "heart")
                                }.accessibilityLabel("\(store.favorites.contains(product.id) ? "Unsave" : "Save") \(product.title)")
                            }
                        }
                    }
                }.padding()
            }
            .navigationTitle(favoritesOnly ? "Saved items" : "OCG Marketplace")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $search, prompt: "Search products")
            .refreshable { await store.refresh() }
            .toolbar { Button { Task { await store.refresh() } } label: { Image(systemName: "arrow.clockwise") }.disabled(store.loading).accessibilityLabel("Refresh catalog") }
        }
    }
}

struct ProductDetail: View {
    @EnvironmentObject private var store: Store
    let product: Product
    @State private var addToCollection = false
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                TabView {
                    ForEach(product.images, id: \.self) { ProductImage(url: $0).padding() }
                }.tabViewStyle(.page).frame(height: 330).background(Color(.secondarySystemBackground))
                Text(product.category).font(.subheadline).foregroundStyle(.secondary)
                Text(product.title).font(.title.bold())
                Text(product.subtitle)
                Text(product.price, format: .currency(code: "USD")).font(.title2.bold())
                Text("Listed price only. Availability, shipping, tax and final total are confirmed on the OCG website.")
                    .font(.footnote).foregroundStyle(.secondary)
                // Open the existing merchant checkout in the system browser, without embedding payment SDKs.
                Link(destination: URL(string: "https://ocgcustomslab.com/#catalog")!) {
                    Label("Check availability on website", systemImage: "safari").frame(maxWidth: .infinity)
                }.buttonStyle(.borderedProminent)
                Button { store.toggleFavorite(product.id) } label: {
                    Label(store.favorites.contains(product.id) ? "Remove from saved" : "Save item", systemImage: "heart")
                }.buttonStyle(.bordered)
                Button { addToCollection = true } label: { Label("Add to my collection", systemImage: "plus") }
                    .disabled(store.storageError != nil)
                ShareLink(item: "\(product.title) — https://ocgcustomslab.com/#catalog") { Label("Share item", systemImage: "square.and.arrow.up") }
            }.padding()
        }
        .navigationTitle("Item details").navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $addToCollection) { CollectionEditor(item: CollectionItem(title: product.title, category: product.category, notes: "")) }
    }
}

struct CollectionView: View {
    @EnvironmentObject private var store: Store
    @State private var editing: CollectionItem?
    @State private var search = ""
    private var items: [CollectionItem] {
        store.collection.filter { search.isEmpty || ($0.title + " " + $0.category + " " + $0.notes).localizedCaseInsensitiveContains(search) }
    }
    var body: some View {
        NavigationStack {
            List {
                Section { Text("Your personal inventory stays on this device. Adding an item here does not buy it.").font(.footnote).foregroundStyle(.secondary) }
                if let error = store.storageError { Text(error).foregroundStyle(.red) }
                if items.isEmpty {
                    ContentUnavailableView("Your collection", systemImage: "square.stack.3d.up", description: Text("Keep a record of the cards, coins and other pieces you own."))
                }
                ForEach(items) { item in
                    Button { editing = item } label: {
                        VStack(alignment: .leading, spacing: 5) {
                            Text(item.title).font(.headline).foregroundStyle(.primary)
                            Text(item.category).font(.caption).foregroundStyle(.secondary)
                            if !item.notes.isEmpty { Text(item.notes).font(.subheadline).foregroundStyle(.secondary).lineLimit(2) }
                        }
                    }.disabled(store.storageError != nil)
                }.onDelete { offsets in store.remove(Set(offsets.map { items[$0].id })) }
            }
            .navigationTitle("My collection")
            .searchable(text: $search, prompt: "Search your collection")
            .toolbar {
                Button { editing = CollectionItem(title: "", category: "Trading Cards", notes: "") } label: { Image(systemName: "plus") }
                    .disabled(store.storageError != nil).accessibilityLabel("Add collection item")
                if !store.collection.isEmpty {
                    ShareLink(item: store.collection.map { "\($0.title) | \($0.category)\n\($0.notes)" }.joined(separator: "\n\n")) {
                        Image(systemName: "square.and.arrow.up")
                    }.accessibilityLabel("Export collection")
                }
            }
            .sheet(item: $editing) { CollectionEditor(item: $0) }
        }
    }
}

struct CollectionEditor: View {
    @EnvironmentObject private var store: Store
    @Environment(\.dismiss) private var dismiss
    @State var item: CollectionItem
    var body: some View {
        NavigationStack {
            Form {
                TextField("Item name", text: $item.title)
                TextField("Category", text: $item.category)
                Section("Notes, condition or certificate number") { TextEditor(text: $item.notes).frame(minHeight: 140) }
                Text("Stored locally on this device. Export your collection before deleting the app.").font(.footnote)
            }
            .navigationTitle("Collection item")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        item.title = item.title.trimmingCharacters(in: .whitespacesAndNewlines)
                        store.save(item); dismiss()
                    }.disabled(item.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || store.storageError != nil)
                }
            }
        }
    }
}

struct AboutView: View {
    var body: some View {
        NavigationStack {
            List {
                Section("OCG Marketplace") {
                    Text("Discover cards, coins, art and collectibles. Save your favorites and keep a personal inventory of your collection.")
                    Link("Visit OCG website", destination: URL(string: "https://ocgcustomslab.com/")!)
                }
                Section("Orders and support") {
                    Text("Purchases take place on our website using its checkout. Contact OCG for order questions or damaged and incorrect items.")
                    Link("Email OCG", destination: URL(string: "mailto:hassanchicago65@gmail.com")!)
                    Link("Shipping and return information", destination: URL(string: "https://ocgcustomslab.com/#returns")!)
                }
                Section("Privacy") {
                    Text("Favorites and collection notes are saved on your device. No account is required. The app requests the catalog and images from the OCG website. Your browser and the checkout providers handle purchases under their own privacy policies.")
                    Link("Website privacy policy", destination: URL(string: "https://ocgcustomslab.com/#privacy")!)
                }
                Section { Text("Version 1.0").foregroundStyle(.secondary) }
            }.navigationTitle("Help & information")
        }
    }
}
