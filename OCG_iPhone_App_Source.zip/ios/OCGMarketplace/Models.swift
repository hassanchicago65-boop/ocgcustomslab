import Foundation
import Combine

struct Product: Codable, Identifiable, Equatable {
    let id: String
    let category: String
    let title: String
    let subtitle: String
    let images: [URL]
    let price: Double
    let shipping: Double
}

struct CollectionItem: Codable, Identifiable, Equatable {
    var id = UUID()
    var title: String
    var category: String
    var notes: String
    var added = Date()
}

enum CatalogError: Error { case invalid }

enum Catalog {
    static func decode(_ data: Data) throws -> [Product] {
        let products = try JSONDecoder().decode([Product].self, from: data)
        guard !products.isEmpty,
              Set(products.map(\.id)).count == products.count,
              products.allSatisfy({ !$0.id.isEmpty && !$0.title.isEmpty && $0.price >= 0 && $0.shipping >= 0 &&
                  !$0.images.isEmpty && $0.images.allSatisfy({ $0.scheme == "https" && $0.host == "ocgcustomslab.com" }) })
        else { throw CatalogError.invalid }
        return products
    }
}

@MainActor
final class Store: ObservableObject {
    @Published var products: [Product] = []
    @Published var favorites: Set<String> = []
    @Published var collection: [CollectionItem] = []
    @Published var catalogMessage = "Saved catalog. Check availability and final price on the website."
    @Published var loading = false
    @Published var storageError: String?
    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        favorites = Set(defaults.stringArray(forKey: "favorites") ?? [])
        if let data = defaults.data(forKey: "collection") {
            do { collection = try JSONDecoder().decode([CollectionItem].self, from: data) }
            catch { storageError = "Your saved collection could not be read. It has not been overwritten." }
        }
        if let data = defaults.data(forKey: "catalog"), let saved = try? Catalog.decode(data) {
            products = saved
        } else if let url = Bundle.main.url(forResource: "catalog", withExtension: "json"),
                  let data = try? Data(contentsOf: url), let bundled = try? Catalog.decode(data) {
            products = bundled
        }
    }

    func toggleFavorite(_ id: String) {
        if favorites.contains(id) { favorites.remove(id) } else { favorites.insert(id) }
        defaults.set(Array(favorites), forKey: "favorites")
    }

    func save(_ item: CollectionItem) {
        guard storageError == nil else { return }
        if let index = collection.firstIndex(where: { $0.id == item.id }) { collection[index] = item }
        else { collection.insert(item, at: 0) }
        persistCollection()
    }

    func remove(_ ids: Set<UUID>) {
        guard storageError == nil else { return }
        collection.removeAll { ids.contains($0.id) }
        persistCollection()
    }

    private func persistCollection() {
        do { defaults.set(try JSONEncoder().encode(collection), forKey: "collection") }
        catch { storageError = "Your changes could not be saved." }
    }

    func refresh() async {
        guard !loading else { return }
        loading = true
        defer { loading = false }
        do {
            let url = URL(string: "https://ocgcustomslab.com/catalog.json")!
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw CatalogError.invalid }
            let updated = try Catalog.decode(data)
            products = updated
            defaults.set(data, forKey: "catalog")
            catalogMessage = "Catalog refreshed. Checkout confirms stock, shipping and tax."
        } catch {
            catalogMessage = "Could not refresh. Showing saved catalog; verify stock and prices on the website."
        }
    }
}
