import Foundation
import Combine
import UIKit
import ImageIO

struct Product: Codable, Identifiable, Equatable {
    let id: String
    let category: String
    let title: String
    let subtitle: String
    let images: [URL]
    let price: Double
    let shipping: Double
    let paypalCartId: String?

    var websiteURL: URL {
        var components = URLComponents(string: "https://ocgcustomslab.com/")!
        components.fragment = "item-\(id)"
        return components.url!
    }
}

struct CartLine: Identifiable {
    let product: Product
    let quantity: Int
    var id: String { product.id }
}

struct CollectionItem: Codable, Identifiable, Equatable {
    var id = UUID()
    var title: String
    var category: String
    var notes: String
    var added = Date()
}

enum CatalogError: Error { case invalid }

enum Catalog {
    static func checkoutURL(for lines: [CartLine]) -> URL? {
        guard !lines.isEmpty, lines.allSatisfy({ $0.product.paypalCartId?.isEmpty == false }) else { return nil }
        let items = lines.map { "\($0.product.id):\($0.quantity)" }.joined(separator: ",")
        var components = URLComponents(string: "https://ocgcustomslab.com/app-checkout.html")
        components?.queryItems = [URLQueryItem(name: "items", value: items)]
        return components?.url
    }

    static func decode(_ data: Data) throws -> [Product] {
        let products = try JSONDecoder().decode([Product].self, from: data)
        guard !products.isEmpty,
              Set(products.map(\.id)).count == products.count,
              products.allSatisfy({ !$0.id.isEmpty && !$0.title.isEmpty && $0.price >= 0 && $0.shipping >= 0 && ($0.paypalCartId == nil || !$0.paypalCartId!.isEmpty) &&
                  !$0.images.isEmpty && $0.images.allSatisfy({ $0.scheme == "https" && $0.host == "ocgcustomslab.com" }) })
        else { throw CatalogError.invalid }
        return products
    }
}

@MainActor
final class Store: ObservableObject {
    @Published var products: [Product] = []
    @Published var favorites: Set<String> = []
    @Published var cart: [String: Int] = [:]
    @Published var collection: [CollectionItem] = []
    @Published var catalogMessage = "Saved catalog. Check availability and final price on the website."
    @Published var loading = false
    @Published var catalogOffline = false
    @Published var storageError: String?
    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        favorites = Set(defaults.stringArray(forKey: "favorites") ?? [])
        cart = defaults.dictionary(forKey: "cart") as? [String: Int] ?? [:]
        if let data = defaults.data(forKey: "collection") {
            do { collection = try JSONDecoder().decode([CollectionItem].self, from: data) }
            catch { storageError = "Your saved collection could not be read. It has not been overwritten." }
        }
        if let data = defaults.data(forKey: "catalog"), let saved = try? Catalog.decode(data) {
            products = saved
        } else if let url = Bundle.main.url(forResource: "catalog", withExtension: "json"),
                  let data = try? Data(contentsOf: url), let bundled = try? Catalog.decode(data) {
            products = bundled
        }
    }

    func toggleFavorite(_ id: String) {
        if favorites.contains(id) { favorites.remove(id) } else { favorites.insert(id) }
        defaults.set(Array(favorites), forKey: "favorites")
    }

    var cartCount: Int { cart.values.reduce(0, +) }
    var cartLines: [CartLine] {
        products.compactMap { product in
            guard let quantity = cart[product.id], quantity > 0 else { return nil }
            return CartLine(product: product, quantity: quantity)
        }
    }
    var cartSubtotal: Double { cartLines.reduce(0) { $0 + $1.product.price * Double($1.quantity) } }
    // Catalog shipping is a listed rate per product, not per unit in the cart.
    var cartShippingEstimate: Double { cartLines.reduce(0) { $0 + $1.product.shipping } }

    func addToCart(_ id: String) {
        guard products.contains(where: { $0.id == id }) else { return }
        cart[id] = min(cart[id, default: 0] + 1, 99)
        persistCart()
    }

    func setCartQuantity(_ quantity: Int, for id: String) {
        guard products.contains(where: { $0.id == id }) else { return }
        if quantity <= 0 { cart.removeValue(forKey: id) }
        else { cart[id] = min(quantity, 99) }
        persistCart()
    }

    func removeFromCart(_ id: String) {
        cart.removeValue(forKey: id)
        persistCart()
    }

    private func persistCart() {
        defaults.set(cart, forKey: "cart")
    }

    func save(_ item: CollectionItem) {
        guard storageError == nil else { return }
        if let index = collection.firstIndex(where: { $0.id == item.id }) { collection[index] = item }
        else { collection.insert(item, at: 0) }
        persistCollection()
    }

    func remove(_ ids: Set<UUID>) {
        guard storageError == nil else { return }
        collection.removeAll { ids.contains($0.id) }
        persistCollection()
    }

    private func persistCollection() {
        do { defaults.set(try JSONEncoder().encode(collection), forKey: "collection") }
        catch { storageError = "Your changes could not be saved." }
    }

    func refresh() async {
        guard !loading else { return }
        loading = true
        defer { loading = false }
        do {
            let url = URL(string: "https://ocgcustomslab.com/catalog.json")!
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw CatalogError.invalid }
            let decoded = try Catalog.decode(data)
            // Keep hosted PayPal button IDs from the signed app catalog if an older
            // website catalog response does not yet include them.
            let bundledCheckoutIDs = Dictionary(uniqueKeysWithValues: products.compactMap { product in
                product.paypalCartId.map { (product.id, $0) }
            })
            let updated = decoded.map { product -> Product in
                guard product.paypalCartId == nil,
                      let cartID = bundledCheckoutIDs[product.id] else { return product }
                return Product(id: product.id, category: product.category, title: product.title,
                               subtitle: product.subtitle, images: product.images, price: product.price,
                               shipping: product.shipping, paypalCartId: cartID)
            }
            products = updated
            defaults.set(data, forKey: "catalog")
            catalogMessage = "Catalog refreshed. Checkout confirms stock, shipping and tax."
            catalogOffline = false
        } catch {
            catalogMessage = "Could not refresh. Showing saved catalog; verify stock and prices on the website."
            catalogOffline = true
        }
    }
}

/// Local product photos appear immediately, including on the first offline launch.
/// Network photos use a bounded request, thumbnail decoding and an in-memory cache.
@MainActor
final class ProductImageLoader: ObservableObject {
    @Published var image: UIImage?
    @Published var failed = false
    private static let cache: NSCache<NSURL, UIImage> = {
        let cache = NSCache<NSURL, UIImage>()
        cache.totalCostLimit = 32 * 1024 * 1024
        return cache
    }()

    func load(_ url: URL?) async {
        failed = false
        image = nil
        guard let url else { failed = true; return }
        if let cached = Self.cache.object(forKey: url as NSURL) {
            image = cached
            return
        }
        // XcodeGen copies resource files to the bundle; try both layouts.
        let name = url.lastPathComponent
        let local = Bundle.main.url(forResource: name, withExtension: nil)
            ?? Bundle.main.url(forResource: name, withExtension: nil, subdirectory: "ProductImages")
        if let local, let data = try? Data(contentsOf: local) {
            image = Self.thumbnail(data)
        }
        do {
            let request = URLRequest(url: url, cachePolicy: .returnCacheDataElseLoad, timeoutInterval: 12)
            let (data, response) = try await URLSession.shared.data(for: request)
            try Task.checkCancellation()
            guard (response as? HTTPURLResponse)?.statusCode == 200,
                  data.count <= 12 * 1024 * 1024,
                  let decoded = Self.thumbnail(data) else { throw CatalogError.invalid }
            Self.cache.setObject(decoded, forKey: url as NSURL, cost: Int(decoded.size.width * decoded.size.height * 4))
            image = decoded
        } catch {
            if Task.isCancelled { return }
            failed = image == nil
        }
    }

    private static func thumbnail(_ data: Data) -> UIImage? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 1000
              ] as CFDictionary) else { return nil }
        return UIImage(cgImage: image)
    }
}
