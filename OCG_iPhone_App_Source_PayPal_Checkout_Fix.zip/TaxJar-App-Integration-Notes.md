# OCG app PayPal + TaxJar update

This archive updates the iPhone app checkout so it collects a US shipping address before opening PayPal, sends that address with the cart to `POST /api/orders`, displays the TaxJar amount returned by the Worker, and calls the existing capture route shape `POST /api/orders/{id}/capture`.

It also includes `paypal-worker-taxjar.js`, the matching Cloudflare Worker source. Keep the existing Worker name `ocg-paypal-checkout` and the `api.ocgcustomslab.com` domain. Do not change the website checkout or the catalog Worker.

## Worker configuration

Keep PayPal and TaxJar keys in Cloudflare Worker settings, never in source code:

- Existing: `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET` (secret), `PAYPAL_MERCHANT_ID`, `PAYPAL_MODE=sandbox`
- Add: `TAXJAR_API_KEY` (secret), `TAXJAR_MODE=sandbox`
- Add ship-from settings used by TaxJar: `FROM_STREET`, `FROM_CITY`, `FROM_STATE`, `FROM_ZIP`

Set the ship-from values to the real address from which OCG ships orders, and set TaxJar nexus in the TaxJar account. Sandbox mode is the default in the provided Worker code.

## Important completion status

The new iOS source and Worker source must both be installed before testing. The Worker cannot calculate tax if the older TestFlight app sends only cart items. This archive does not contain any API credentials, and it has not been deployed or tested against PayPal/TaxJar Sandbox.
