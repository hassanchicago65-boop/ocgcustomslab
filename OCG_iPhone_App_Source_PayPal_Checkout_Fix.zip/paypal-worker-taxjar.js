// OCG app PayPal checkout Worker with TaxJar.
// Keep PAYPAL_CLIENT_SECRET and TAXJAR_API_KEY as Cloudflare secrets.
// App requests must send items plus address: fullName, street, street2,
// city, state, zip, country (US).

const CATALOG = {
  "alohi-gilman-slab": { name: "Alohi Gilman OCG Custom Slab", price: 7.00, shipping: 4.99 },
  "austria-1974-10-schilling": { name: "1974 Austria 10 Schilling Copper-Nickel Coin", price: 3.50, shipping: 1.36 },
  "royal-myanmar-teamix": { name: "Royal Myanmar Teamix Solid Milk Tea 30 x 20g", price: 9.50, shipping: 4.99 },
  "paoh-traditional-headgear-moe-myint-zaw": { name: "Paoh Traditional Headgear", price: 1550.00, shipping: 0.00 },
};
const TAXJAR_API_VERSION = "2022-01-24";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders() });
    if (url.pathname === "/health" && request.method === "GET") return json({ ok: true });
    if (url.pathname === "/api/config" && request.method === "GET") {
      if (!env.PAYPAL_CLIENT_ID || !env.PAYPAL_MERCHANT_ID) return json({ error: "PayPal app settings are missing" }, 503);
      return json({ clientID: env.PAYPAL_CLIENT_ID, merchantID: env.PAYPAL_MERCHANT_ID });
    }
    if (url.pathname === "/api/orders" && request.method === "POST") return createOrder(request, env);
    const capture = url.pathname.match(/^\/api\/orders\/([A-Z0-9-]+)\/capture$/i);
    if (capture && request.method === "POST") return captureOrder(capture[1], env);
    return json({ error: "Not found" }, 404);
  },
};

async function createOrder(request, env) {
  try {
    requireEnv(env, ["PAYPAL_CLIENT_ID", "PAYPAL_CLIENT_SECRET", "TAXJAR_API_KEY", "FROM_STREET", "FROM_CITY", "FROM_STATE", "FROM_ZIP"]);
    const body = await request.json();
    if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 20) return json({ error: "Invalid items" }, 400);
    const address = normalizeAddress(body.address);
    const seen = new Set();
    const items = [];
    let subtotalCents = 0;
    let shippingCents = 0;

    for (const line of body.items) {
      const product = CATALOG[line.id];
      if (!product || !Number.isInteger(line.quantity) || line.quantity < 1 || line.quantity > 10 || seen.has(line.id)) {
        return json({ error: "Invalid item or quantity" }, 400);
      }
      seen.add(line.id);
      const unitCents = toCents(product.price);
      const lineShippingCents = toCents(product.shipping);
      subtotalCents += unitCents * line.quantity;
      // Preserve the current checkout rule: one listed shipping fee per product line.
      shippingCents += lineShippingCents;
      items.push({ id: line.id, name: product.name, quantity: line.quantity, unitCents });
    }

    const taxCents = await calculateTax(env, items, address, subtotalCents, shippingCents);
    const totalCents = subtotalCents + shippingCents + taxCents;
    const token = await getAccessToken(env);
    const order = await paypalFetch(env, "/v2/checkout/orders", token, {
      method: "POST",
      headers: { "PayPal-Request-Id": crypto.randomUUID() },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [{
          custom_id: "ocg-app-taxjar-v1",
          description: "OCG Marketplace order",
          amount: {
            currency_code: "USD",
            value: money(totalCents),
            breakdown: {
              item_total: { currency_code: "USD", value: money(subtotalCents) },
              shipping: { currency_code: "USD", value: money(shippingCents) },
              tax_total: { currency_code: "USD", value: money(taxCents) },
            },
          },
          items: items.map(item => ({
            name: item.name,
            sku: item.id,
            quantity: String(item.quantity),
            unit_amount: { currency_code: "USD", value: money(item.unitCents) },
            category: "PHYSICAL_GOODS",
          })),
          shipping: {
            name: { full_name: address.fullName },
            address: {
              address_line_1: address.street,
              ...(address.street2 ? { address_line_2: address.street2 } : {}),
              admin_area_2: address.city,
              admin_area_1: address.state,
              postal_code: address.zip,
              country_code: "US",
            },
          },
        }],
        application_context: { shipping_preference: "SET_PROVIDED_ADDRESS", user_action: "PAY_NOW" },
      }),
    });
    const approvalUrl = order.links && order.links.find(link => link.rel === "approve")?.href;
    if (!order.id || !approvalUrl) throw new Error("PayPal did not return an approval link.");
    return json({ id: order.id, approvalUrl, tax: money(taxCents), total: money(totalCents) }, 201);
  } catch (error) {
    console.error("PayPal/TaxJar create order failed", error?.message);
    return json({ error: error?.message || "Could not create PayPal order" }, 502);
  }
}

function normalizeAddress(input) {
  if (!input || typeof input !== "object") throw new Error("Enter your shipping address before checkout.");
  const address = {
    fullName: String(input.fullName || "").trim().slice(0, 120),
    street: String(input.street || "").trim().slice(0, 200),
    street2: String(input.street2 || "").trim().slice(0, 200),
    city: String(input.city || "").trim().slice(0, 100),
    state: String(input.state || "").trim().toUpperCase(),
    zip: String(input.zip || "").trim(),
    country: String(input.country || "US").trim().toUpperCase(),
  };
  if (!address.fullName || !address.street || !address.city || !address.state || !address.zip) {
    throw new Error("Enter your full US shipping address.");
  }
  if (address.country !== "US" || !/^[A-Z]{2}$/.test(address.state) || !/^\d{5}(-\d{4})?$/.test(address.zip)) {
    throw new Error("This checkout currently accepts US shipping addresses only.");
  }
  return address;
}

async function calculateTax(env, items, address, subtotalCents, shippingCents) {
  const root = env.TAXJAR_MODE === "live" ? "https://api.taxjar.com" : "https://api.sandbox.taxjar.com";
  const payload = {
    from_country: "US", from_street: env.FROM_STREET, from_city: env.FROM_CITY,
    from_state: env.FROM_STATE, from_zip: env.FROM_ZIP,
    to_country: address.country, to_street: address.street, to_city: address.city,
    to_state: address.state, to_zip: address.zip,
    amount: money(subtotalCents + shippingCents), shipping: money(shippingCents),
    line_items: items.map(item => ({ id: item.id, quantity: item.quantity, unit_price: money(item.unitCents) })),
  };
  const response = await fetch(root + "/v2/taxes", {
    method: "POST",
    headers: { Authorization: "Bearer " + env.TAXJAR_API_KEY, "Content-Type": "application/json", "x-api-version": TAXJAR_API_VERSION },
    body: JSON.stringify(payload),
  });
  const result = await response.json().catch(() => ({}));
  const tax = Number(result?.tax?.amount_to_collect);
  if (!response.ok || !Number.isFinite(tax) || tax < 0) throw new Error("TaxJar could not calculate tax for this address.");
  return Math.round(tax * 100);
}

async function captureOrder(orderID, env) {
  try {
    const token = await getAccessToken(env);
    const order = await paypalFetch(env, "/v2/checkout/orders/" + encodeURIComponent(orderID), token, { method: "GET" });
    if (order.status !== "APPROVED" || order.purchase_units?.[0]?.custom_id !== "ocg-app-taxjar-v1") {
      return json({ error: "This order is not ready to capture" }, 409);
    }
    const result = await paypalFetch(env, "/v2/checkout/orders/" + encodeURIComponent(orderID) + "/capture", token, {
      method: "POST", headers: { "PayPal-Request-Id": "capture-" + orderID }, body: "{}",
    });
    if (result.status !== "COMPLETED") return json({ error: "Payment is not completed" }, 409);
    const capture = result.purchase_units?.[0]?.payments?.captures?.[0];
    let taxRecorded = false;
    if (capture?.id) {
      try { await recordTaxJarTransaction(env, order, capture); taxRecorded = true; }
      catch (error) { console.error("TaxJar transaction recording failed", orderID, error?.message); }
    }
    return json({ status: result.status, taxRecorded });
  } catch (error) {
    console.error("PayPal capture failed", error?.message);
    return json({ error: "Could not confirm PayPal payment" }, 502);
  }
}

async function recordTaxJarTransaction(env, order, capture) {
  const unit = order.purchase_units?.[0];
  const address = unit?.shipping?.address;
  const breakdown = unit?.amount?.breakdown;
  const orderItems = unit?.items || [];
  if (!address || !breakdown?.item_total || !capture?.id || !orderItems.length) throw new Error("Order tax details are incomplete.");
  const payload = {
    transaction_id: capture.id,
    transaction_date: capture.create_time || new Date().toISOString(),
    from_country: "US", from_street: env.FROM_STREET, from_city: env.FROM_CITY,
    from_state: env.FROM_STATE, from_zip: env.FROM_ZIP,
    to_country: address.country_code, to_street: address.address_line_1,
    to_city: address.admin_area_2, to_state: address.admin_area_1, to_zip: address.postal_code,
    amount: Number(breakdown.item_total.value) + Number(breakdown.shipping?.value || 0),
    shipping: Number(breakdown.shipping?.value || 0),
    sales_tax: Number(breakdown.tax_total?.value || 0),
    line_items: orderItems.map(item => ({
      quantity: Number(item.quantity), product_identifier: String(item.sku || ""),
      description: String(item.name || ""), unit_price: Number(item.unit_amount?.value),
    })),
  };
  const root = env.TAXJAR_MODE === "live" ? "https://api.taxjar.com" : "https://api.sandbox.taxjar.com";
  const response = await fetch(root + "/v2/transactions/orders", {
    method: "POST",
    headers: { Authorization: "Bearer " + env.TAXJAR_API_KEY, "Content-Type": "application/json", "x-api-version": TAXJAR_API_VERSION },
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error("TaxJar returned HTTP " + response.status);
}

async function getAccessToken(env) {
  const credentials = btoa(String(env.PAYPAL_CLIENT_ID) + ":" + String(env.PAYPAL_CLIENT_SECRET));
  const response = await fetch(apiRoot(env) + "/v1/oauth2/token", {
    method: "POST", headers: { Authorization: "Basic " + credentials, "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials",
  });
  if (!response.ok) throw new Error("PayPal OAuth " + response.status);
  const result = await response.json();
  if (!result.access_token) throw new Error("PayPal did not return an access token.");
  return result.access_token;
}

async function paypalFetch(env, path, token, init) {
  const response = await fetch(apiRoot(env) + path, {
    ...init,
    headers: { Authorization: "Bearer " + token, "Content-Type": "application/json", ...(init.headers || {}) },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error("PayPal API " + response.status + ": " + JSON.stringify(body.details || body));
  return body;
}

function apiRoot(env) {
  return env.PAYPAL_MODE === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";
}
function toCents(value) { return Math.round(Number(value) * 100); }
function money(cents) { return (Number(cents) / 100).toFixed(2); }
function requireEnv(env, names) {
  const missing = names.filter(name => !String(env[name] || "").trim());
  if (missing.length) throw new Error("Worker settings missing: " + missing.join(", "));
}
function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status, headers: { ...corsHeaders(), "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}
function corsHeaders() {
  return { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "POST, GET, OPTIONS", "Access-Control-Allow-Headers": "Content-Type", Vary: "Origin" };
}
