Checkout alignment for the current ocg-paypal-checkout Worker

The iOS client now posts the cart to https://api.ocgcustomslab.com/api/orders and decodes the current Worker response fields `id` and `approvalUrl`. Cart item payload remains {items:[{id,quantity}]}. Website checkout routes are not changed by this app source update.

For successful payment capture and a clear return page, apply the additive Worker changes in app-paypal-worker/ADD_TO_EXISTING_WORKER.txt to the existing Cloudflare Worker. Do not replace the existing Worker with app-paypal-worker/worker.js; preserve the website's current routes.

Validation: source/archive integrity can be checked locally. Xcode build and live PayPal Sandbox approval/capture still need to run in the GitHub Actions/TestFlight and PayPal Sandbox environment.
