const CATALOG = "https://ocgcustomslab.com/catalog.json";
const apiBase = env => env.PAYPAL_ENV === "sandbox" ? "https://api-m.sandbox.paypal.com" : "https://api-m.paypal.com";

function reply(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
}
function page(title, message) {
  return new Response(`<!doctype html><meta name="viewport" content="width=device-width"><title>${title}</title><main style="font:18px Arial;max-width:600px;margin:12vh auto;padding:24px"><h1>${title}</h1><p>${message}</p><p>You may close this page and return to OCG Marketplace.</p></main>`, {headers:{"content-type":"text/html; charset=utf-8","cache-control":"no-store"}});
}
async function accessToken(env) {
  const auth = btoa(`${env.PAYPAL_CLIENT_ID}:${env.PAYPAL_CLIENT_SECRET}`);
  const response = await fetch(`${apiBase(env)}/v1/oauth2/token`, {method:"POST",headers:{authorization:`Basic ${auth}`,accept:"application/json","content-type":"application/x-www-form-urlencoded"},body:"grant_type=client_credentials"});
  const data = await response.json();
  if (!response.ok || !data.access_token) throw new Error("PayPal authentication failed");
  return data.access_token;
}
async function handleCreate(request, env) {
  const input = await request.json();
  if (!Array.isArray(input.items) || !input.items.length || input.items.length > 20) return reply({error:"Invalid cart"},400);
  const catalogResponse = await fetch(CATALOG, {headers:{accept:"application/json"}, cf:{cacheTtl:0}});
  if (!catalogResponse.ok) return reply({error:"Catalog unavailable"},503);
  const products = await catalogResponse.json();
  const byId = new Map(products.filter(p=>p.status !== "Sold out").map(p=>[p.id,p]));
  const lines = [];
  for (const raw of input.items) {
    const p = byId.get(raw.id), qty = Number(raw.quantity);
    if (!p || !Number.isInteger(qty) || qty < 1 || qty > 99 || (Number.isInteger(p.quantity) && qty > p.quantity)) return reply({error:`Unavailable item: ${raw.id}`},409);
    const price=Number(p.price), shipping=Number(p.shipping||0);
    if (!Number.isFinite(price) || price <= 0 || !Number.isFinite(shipping) || shipping < 0) return reply({error:"Invalid product price"},400);
    lines.push({id:p.id,title:String(p.title).slice(0,127),price,shipping,quantity:qty});
  }
  const itemTotal=lines.reduce((n,p)=>n+p.price*p.quantity,0);
  const shipping=lines.reduce((n,p)=>n+p.shipping,0);
  const total=itemTotal+shipping;
  const token=await accessToken(env);
  const orderBody={intent:"CAPTURE",purchase_units:[{reference_id:"ocg-app-cart",description:"OCG Marketplace app order",items:lines.map(p=>({name:p.title,quantity:String(p.quantity),unit_amount:{currency_code:"USD",value:p.price.toFixed(2)},category:"PHYSICAL_GOODS"})),amount:{currency_code:"USD",value:total.toFixed(2),breakdown:{item_total:{currency_code:"USD",value:itemTotal.toFixed(2)},shipping:{currency_code:"USD",value:shipping.toFixed(2)}}}}],application_context:{brand_name:"OCG Marketplace",user_action:"PAY_NOW",shipping_preference:"GET_FROM_FILE",return_url:`https://api.ocgcustomslab.com/app/return`,cancel_url:`https://api.ocgcustomslab.com/app/cancel`}};
  const created=await fetch(`${apiBase(env)}/v2/checkout/orders`,{method:"POST",headers:{authorization:`Bearer ${token}`,"content-type":"application/json","PayPal-Request-Id":crypto.randomUUID()},body:JSON.stringify(orderBody)});
  const order=await created.json();
  if(!created.ok) return reply({error:"PayPal could not create the order",details:order.message||order.name},502);
  const approve=order.links?.find(link=>(link.rel==="approve" || link.rel==="payer-action"))?.href;
  if(!approve) return reply({error:"PayPal approval link missing"},502);
  return reply({orderID:order.id,approveURL:approve});
}
async function handleReturn(url, env) {
  const id=url.searchParams.get("token");
  if(!id || !/^[A-Z0-9-]{5,40}$/.test(id)) return page("Checkout not completed","Missing or invalid PayPal order.");
  const token=await accessToken(env);
  const response=await fetch(`${apiBase(env)}/v2/checkout/orders/${encodeURIComponent(id)}/capture`,{method:"POST",headers:{authorization:`Bearer ${token}`,"content-type":"application/json","PayPal-Request-Id":crypto.randomUUID()},body:"{}"});
  const result=await response.json();
  if(!response.ok || result.status!=="COMPLETED") return page("Payment not confirmed","PayPal did not confirm this payment. Please contact OCG before trying again.");
  return page("Payment confirmed","Your OCG app order was paid successfully. PayPal transaction: "+String(result.purchase_units?.[0]?.payments?.captures?.[0]?.id||"confirmed"));
}
export default { async fetch(request,env) {
  const url=new URL(request.url);
  try {
    if(request.method==="GET" && url.pathname==="/app/health") return reply({ok:true,service:"ocg-app-payments"});
    if(request.method==="POST" && url.pathname==="/app/orders") return await handleCreate(request,env);
    if(request.method==="GET" && url.pathname==="/app/return") return await handleReturn(url,env);
    if(request.method==="GET" && url.pathname==="/app/cancel") return page("Payment cancelled","No payment was taken. Return to OCG Marketplace to review your cart.");
    return reply({error:"Not found"},404);
  } catch (error) { return reply({error:"Checkout service error",details:String(error.message||error)},500); }
} };
