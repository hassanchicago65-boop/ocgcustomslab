# OCG app-only PayPal checkout

This Worker serves only `api.ocgcustomslab.com/app/*`. It does not change the website's existing checkout or catalog Worker.

## Configure securely

1. Deploy this Worker as `ocg-app-payments` and confirm the route `api.ocgcustomslab.com/app/*` is attached.
2. Start with a PayPal **Sandbox** REST app. In Cloudflare Worker settings, add encrypted secrets `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` from that Sandbox app. Keep `PAYPAL_ENV` set to `sandbox`.
3. Check `https://api.ocgcustomslab.com/app/health` returns `{"ok":true,...}`.
4. Build/install the updated iOS app and test with PayPal Sandbox buyer credentials only. The app sends item IDs and quantities to this Worker; the Worker reads current listed price/shipping from `/catalog.json`, creates the PayPal order, and captures it after PayPal returns. The OCG website checkout is not called.
5. Only after Sandbox testing and tax/inventory review, replace the Worker secrets with **Live** REST app credentials and change `PAYPAL_ENV` to `live`.

Never put PayPal secrets in the iOS app, GitHub, or a chat message.

## Current limitations to resolve before live sales

- The public catalog currently does not include stock quantities or a reliable sold-out status. This Worker cannot reserve stock or prevent two buyers purchasing the last unit. Add an authoritative inventory check/reservation before enabling live payments.
- Tax is not calculated by this initial Worker. Configure and test tax calculation before live orders if sales tax applies.
- The order includes the catalog's listed shipping amount once per product, matching the app's current estimate; verify combined-shipping policy before live use.
- This is a PayPal approval flow opened from the app, not a native card-entry form. PayPal handles approval securely; the OCG website checkout remains a separate flow.
